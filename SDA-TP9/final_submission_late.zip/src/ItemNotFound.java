/**
 * Created by Johan on 05.12.2016.
 */
public class ItemNotFound extends Exception {
    public ItemNotFound(String message){
        super(message);
    }
}
