2.2) if the load factor is greater than 0.5, the miss rate will be too high, clustering will occure
2.3) it's a prime number

the Main class containes a main() method that print in stdout the miss rate
there is also a test class to ensure that the hashtable implemention behaves correctly