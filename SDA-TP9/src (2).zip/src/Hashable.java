/**
 * Created by Maël Cattin on 05.12.2016.
 */

public interface Hashable {
    int hash(int tableSize);
}
