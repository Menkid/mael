/**
 * @author Maël Cattin
 */

public class LinearProbingTable extends ProbingHashTable {
    @Override
    protected final int findPos(Hashable x) {
        int currentPos = x.hash(array.length);
        // keep looking if currentPos contains an active element
        while(array[currentPos] != null && !array[currentPos].element.equals(x) && array[currentPos].isActive) {
            currentPos++;
            currentPos %= array.length;
        }
        return currentPos;
    }
}
