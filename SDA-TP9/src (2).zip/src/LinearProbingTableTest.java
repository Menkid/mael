/**
 * @author Maël Cattin
 */

import org.junit.*;

import static org.junit.Assert.*;

public class LinearProbingTableTest {
    private LinearProbingTable myTable;
    private static final int TABLE_SIZE = 997;

    @Before
    public void setUp() throws Exception {
        myTable = new LinearProbingTable();
    }

    @Test
    public void hashCalculation() {
        int key = (int)(Math.random() * Integer.MAX_VALUE);
        Hashable a = new HashableImpl(key);
        Hashable b = new HashableImpl(key);
        assertTrue(a.hash(TABLE_SIZE) == b.hash(TABLE_SIZE));
    }

}