/**
 * @author Maël Cattin
 */
public class Main {

    public static void main(String[] args){
        LinearProbingTable myTable = new LinearProbingTable();

        //initialize your hash table, and then:
        int items=500;
        // see above
        int ht_size=997;
        int keysPerCell = 10;
        for(int j=0; j<items; j++){
            // insert data
            int aKey = (int)(java.lang.Math.random()*keysPerCell*ht_size);
            Hashable h = new HashableImpl(aKey);
            myTable.insert(h);
        }
    }


}
