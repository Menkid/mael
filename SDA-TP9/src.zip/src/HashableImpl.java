/**
 * @author Maël Cattin
 */
public class HashableImpl implements Hashable {
    int key;

    public HashableImpl(int key){
        this.key = key;
    }

    @Override
    public int hash(int tableSize) {
        return key % tableSize; // simple modulo
    }
}
