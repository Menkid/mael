/**
 * Created by Johan on 05.12.2016.
 */
public class ItemNotFound extends Exception {
    public ItemNotFound(){
        super();
    }

    public ItemNotFound(String message){
        super(message);
    }

    public ItemNotFound(Throwable cause){
        super(cause);
    }

    public ItemNotFound(String message, Throwable cause){
        super(message, cause);
    }
}
