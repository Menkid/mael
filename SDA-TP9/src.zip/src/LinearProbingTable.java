/**
 * @author Maël Cattin
 */
public class LinearProbingTable extends ProbingHashTable {
    @Override
    protected final int findPos(Hashable x) {
        int currentPos = x.hash(array.length);
        while(array[currentPos] != null && !array[currentPos].element.equals(x)) {
            currentPos++;
            if (currentPos >= array.length)
                currentPos -= array.length;
        }
        return currentPos;
    }
}
