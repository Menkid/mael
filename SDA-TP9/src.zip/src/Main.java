/**
 * Created by Maël Cattin on 05.12.2016.
 */
public class Main {
    //initialize your hash table, and then:
    int items=..
    // see above
    int ht_size=997
    int keysPerCell = 10
    for(int j=0
            ;
    j<items
    ;
    j++)
    {
// insert data
        int
                aKey
                =
                (
                        int
                        )(
                        java
                                .
                                        lang
                                .
                                        Math
                                .
                                        random
                                                ()
                                *
                                keysPerCell
                                *
                                ht_size
                )
                ;
        Hashable h
                =
                new
                        HashableImpl
                        (
                                aKey
                        )
                ;
        theHashTable
                .
                        insert
                                (
                                        h
                                )
        ;
    }
}
