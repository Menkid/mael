2.2) if the load factor is greater than 0.5, the miss rate will be too high, clustering will occure
2.3) it's a prime number